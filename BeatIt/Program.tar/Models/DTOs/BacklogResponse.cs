namespace BeatIt.Models.DTOs;

public class BacklogResponse
{
    public required string GameName { get; set; }
    public DateTime Created_at { get; set; }
}