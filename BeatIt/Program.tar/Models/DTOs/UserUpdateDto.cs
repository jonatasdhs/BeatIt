namespace BeatIt.Models.DTOs
{
    public class UserUpdateDto
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
    }
}