namespace BeatIt.Utils
{
    public enum Status
    {
        ToPlay,
        Finished,
        Playing
    }
}